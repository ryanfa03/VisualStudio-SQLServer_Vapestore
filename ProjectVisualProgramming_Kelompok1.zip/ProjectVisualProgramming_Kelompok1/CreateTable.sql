CREATE DATABASE project
USE project

CREATE TABLE Employee(
EmployeeID			VARCHAR(50) PRIMARY KEY NOT NULL,
EmployeeName		VARCHAR(50) NOT NULL,
EmployeeAddress		VARCHAR(50) NOT NULL,
EmployeePhone		VARCHAR(20) NOT NULL,
)

CREATE TABLE Users(
UserID		VARCHAR(50) PRIMARY KEY NOT NULL,
EmployeeID	VARCHAR(50) NOT NULL FOREIGN KEY REFERENCES Employee(EmployeeID), 
Username	VARCHAR(50) NOT NULL,
Password	VARCHAR(50) NOT NULL,
)

CREATE TABLE Supplier(
SupplierID			VARCHAR(50) PRIMARY KEY NOT NULL,
SupplierName		VARCHAR(50) NOT NULL,
SupplierAddress		VARCHAR(50) NOT NULL,
SupplierPhone		VARCHAR(20) NOT NULL
)

CREATE TABLE ItemCategory(
ItemCategoryID		VARCHAR(50) PRIMARY KEY NOT NULL,
ItemCategoryName	VARCHAR(50) NOT NULL,
)

CREATE TABLE Item(
ItemID				VARCHAR(100) PRIMARY KEY NOT NULL,
ItemCategoryID		VARCHAR(50) FOREIGN KEY REFERENCES ItemCategory(ItemCategoryID) NOT NULL,
ItemName			VARCHAR(50) NOT NULL,
Description			VARCHAR(50) NOT NULL,
ItemQty				INT			NOT NULL,
ItemPrice			INT			NOT NULL
)

CREATE TABLE PurchaseOrder(
PurchaseOrderID		VARCHAR(100) PRIMARY KEY NOT NULL,
EmployeeID			VARCHAR(50) FOREIGN KEY REFERENCES Employee(EmployeeID) NOT NULL,
SupplierID			VARCHAR(50) FOREIGN KEY REFERENCES Supplier(SupplierID) NOT NULL,
OrderDate			DATE NOT NULL
)

CREATE TABLE PurchaseOrderDetail(
PurchaseOrderID		VARCHAR(100) FOREIGN KEY REFERENCES PurchaseOrder(PurchaseOrderID) NOT NULL,
ItemID				VARCHAR(100) FOREIGN KEY REFERENCES Item(ItemID) NOT NULL,
ItemCategoryID		VARCHAR(50) FOREIGN KEY REFERENCES ItemCategory(ItemCategoryID) NOT NULL,
ItemName			VARCHAR(50) NOT NULL,
ItemQty				INT NOT NULL
)

CREATE TABLE PaymentMethod(
PaymentMethodID		VARCHAR(50) PRIMARY KEY NOT NULL,
PaymentName			VARCHAR(50) NOT NULL,
)

CREATE TABLE Orders(
OrderID				VARCHAR(50) PRIMARY KEY NOT NULL,
EmployeeID			VARCHAR(50) FOREIGN KEY REFERENCES Employee(EmployeeID) NOT NULL,
PaymentMethodID		VARCHAR(50) FOREIGN KEY REFERENCES PaymentMethod(PaymentMethodID) NOT NULL,
OrderDate			DATE NOT NULL,
)

CREATE TABLE OrdersDetail(
OrderID				VARCHAR(50) FOREIGN KEY REFERENCES Orders(OrderID) NOT NULL,
ItemID				VARCHAR(100) FOREIGN KEY REFERENCES Item(ItemID) NOT NULL,
ItemCategoryID		VARCHAR(50) FOREIGN KEY REFERENCES ItemCategory(ItemCategoryID) NOT NULL,
ItemName			VARCHAR(50) NOT NULL,
ItemPrice			INT NOT NULL,
OrderQty			INT NOT NULL
)
 
Select * From Users
GO
Select * From Employee
GO
Select * From Supplier
GO
Select * From Item
GO
Select * From ItemCategory
GO
Select * From PurchaseOrder
GO
Select * From PurchaseOrderDetail
GO
Select * From Orders
GO
Select * From OrdersDetail
GO
Select * From PaymentMethod
GO

DROP DATABASE project

INSERT INTO Users VALUES ('US001','EP001', 'ryan123','12345')
INSERT INTO Employee VALUES ('EP001','Ryan', 'Jln. Sudirman')

-- MENGURANGI QUANTITY INVENTORY SETELAH TRANSAKSI
CREATE TRIGGER kurang_barangorder on OrdersDetail
AFTER INSERT
AS
BEGIN
DECLARE @OrderQty INT, @id VARCHAR(100)
SELECT @OrderQty=OrderQty, @id=ItemID
FROM INSERTED
UPDATE Item SET ItemQty = ItemQty - @OrderQty
WHERE ItemID = @id
END

-- MENGUPDATE TRANSAKSI QUANTITY INVENTORY SETELAH EDIT
CREATE TRIGGER update_barangorder on OrdersDetail
AFTER UPDATE
AS
BEGIN
	DECLARE @id VARCHAR(100), @OrderQty INT, @qtylama INT
	SELECT @OrderQty = OrderQty, @id = ItemID FROM INSERTED

	SELECT @qtylama = OrderQty
	FROM DELETED

	UPDATE Item SET ItemQty = ItemQty + @qtylama - @OrderQty
	WHERE ItemID = @id
END

-- MENGEMBALIKAN STOK JIKA TRANSAKSI BATAL
CREATE TRIGGER delete_barangorder on OrdersDetail
AFTER DELETE
AS
BEGIN
DECLARE @OrderQty INT, @id VARCHAR(100)
SELECT @OrderQty = OrderQty, @id = ItemID
FROM DELETED

UPDATE Item SET ItemQty = ItemQty + @OrderQty
WHERE ItemID = @id
END

-- MENAMBAH QUANTITY INVENTORY SETELAH PURCHASE ORDER
CREATE TRIGGER tambah_barangPO on PurchaseOrderDetail
AFTER INSERT
AS
BEGIN
DECLARE @ItemQty INT, @id VARCHAR(100)
SELECT @ItemQty=ItemQty, @id=ItemID
FROM INSERTED
UPDATE Item SET ItemQty = ItemQty + @ItemQty
WHERE ItemID = @id
END

-- MENGUPDATE TRANSAKSI PEMBELIAN QUANTITY INVENTORY SETELAH EDIT
CREATE TRIGGER update_barangpo on PurchaseOrderDetail
AFTER UPDATE
AS
BEGIN
	DECLARE @id VARCHAR(100), @ItemQty INT, @qtylama INT
	SELECT @ItemQty = ItemQty, @id = ItemID FROM INSERTED

	SELECT @qtylama = ItemQty
	FROM DELETED

	UPDATE Item SET ItemQty = ItemQty + @qtylama - @ItemQty
	WHERE ItemID = @id
END

-- MENGEMBALIKAN STOK JIKA TRANSAKSI BATAL
CREATE TRIGGER delete_brgpo on PurchaseOrderDetail
AFTER DELETE
AS
BEGIN
DECLARE @ItemQty INT, @id VARCHAR(100)
SELECT @ItemQty = ItemQty, @id = ItemID
FROM DELETED

UPDATE Item SET ItemQty = ItemQty - @ItemQty
WHERE ItemID = @id
END

