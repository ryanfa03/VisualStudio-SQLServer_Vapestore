﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectVisualProgramming_Kelompok1
{
    public partial class BarangReport : Form
    {
        public BarangReport()
        {
            InitializeComponent();
        }
        private void BarangReport_Load(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand cmd = new SqlCommand("SELECT * FROM ItemCategory", con);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable table1 = new DataTable();
            da.Fill(table1);

            comboBox1.DataSource = table1;
            comboBox1.DisplayMember = "ItemCategoryName";
            comboBox1.ValueMember = "ItemCategoryID";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            ReportDataBarang vcr = new ReportDataBarang();
            crystalReportViewer1.SelectionFormula = "{ItemCategory.ItemCategoryName} = '" + comboBox1.Text + "'";
            crystalReportViewer1.ReportSource = vcr;
        }   
    }
}
