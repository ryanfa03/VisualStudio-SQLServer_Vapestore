﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace ProjectVisualProgramming_Kelompok1
{
    public partial class SalesToFile : Form
    {
        public SalesToFile()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            DataTable dt = new DataTable();
            SqlCommand searchorder = new SqlCommand("SELECT a.OrderID, a.EmployeeID, a.PaymentMethodID, a.OrderDate" +
                ", b.ItemID, b.ItemCategoryID, b.ItemName, b.ItemPrice, b.OrderQty FROM Orders a JOIN OrdersDetail b ON a.OrderID = b.OrderID", con);
            SqlDataAdapter adapter = new SqlDataAdapter(searchorder);
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FileStream fs = new FileStream("C:\\Data\\SalesReport.txt", FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);

            for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    sw.Write("\t" + dataGridView1.Rows[i].Cells[j].Value.ToString() + "\t" + "|");
                }
                sw.WriteLine("");
                sw.WriteLine("-------------------------------------------------------------------------------------------" +
                    "-------------------------------------------------------------------------------");
            }

            sw.Close();
        }

        private void SalesToFile_Load(object sender, EventArgs e)
        {
            label1.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            label1.Text = Baca();
        }
        static string Baca()
        {
            FileStream fs = new FileStream("C:\\Data\\SalesReport.txt", FileMode.OpenOrCreate, FileAccess.Read, FileShare.ReadWrite);
            StreamReader sr = new StreamReader(fs);
            return (sr.ReadToEnd());
            sr.Close();
            fs.Close();
        }

    }
}
