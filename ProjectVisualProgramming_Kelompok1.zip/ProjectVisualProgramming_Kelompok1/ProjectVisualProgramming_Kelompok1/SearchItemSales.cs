﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectVisualProgramming_Kelompok1
{
    public partial class SearchItemSales : Form
    {
        public SearchItemSales()
        {
            InitializeComponent();
        }

        private void SearchItemSales_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projectDataSet13.Item' table. You can move, or remove it, as needed.
            this.itemTableAdapter1.Fill(this.projectDataSet13.Item);
            dataGridView1.Columns[5].DefaultCellStyle.Format = "###,###";

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection conn = new SqlConnection(constring);

            SqlCommand cmd = new SqlCommand("SELECT * FROM Item WHERE ItemID LIKE '%" + textBox1.Text + "%' OR ItemName LIKE '%" + textBox1.Text + "%'", conn);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SalesBarang salesBarang = (SalesBarang)Application.OpenForms["SalesBarang"];
            salesBarang.idBarang.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            salesBarang.idKategori.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            salesBarang.namaBarang.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            salesBarang.hargaBarang.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
        }
    }
}
