﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectVisualProgramming_Kelompok1
{
    public partial class SearchItemCategory : Form
    {
        public SearchItemCategory()
        {
            InitializeComponent();
        }

        private void SearchItemCategory_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projectDataSet10.ItemCategory' table. You can move, or remove it, as needed.
            this.itemCategoryTableAdapter1.Fill(this.projectDataSet10.ItemCategory);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection conn = new SqlConnection(constring);

            SqlCommand cmd = new SqlCommand("SELECT * FROM ItemCategory WHERE ItemCategoryID LIKE '%" + textBox1.Text + "%' OR ItemCategoryName LIKE '%" + textBox1.Text + "%'", conn);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            MasterBarang barang = (MasterBarang)Application.OpenForms["MasterBarang"];
            barang.idKategori.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();


        }
        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

        }

      
    }
}
