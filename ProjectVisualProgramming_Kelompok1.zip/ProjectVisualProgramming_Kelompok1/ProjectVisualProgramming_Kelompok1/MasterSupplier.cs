﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectVisualProgramming_Kelompok1
{
    public partial class MasterSupplier : Form
    {
        public MasterSupplier()
        {
            InitializeComponent();
        }
        
        static string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
        SqlConnection conn = new SqlConnection(constring);

        void generateID()
        {
            long count;
            string urut;
            SqlDataReader rd;
            conn.Open();
            SqlCommand cmd = new SqlCommand("Select SupplierID FROM Supplier " +
                "WHERE SupplierID in(SELECT MAX(SupplierID) FROM Supplier) ORDER BY SupplierID DESC", conn);
            rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                count = Convert.ToInt64(rd[0].ToString().Substring(rd["SupplierID"].ToString().Length - 4, 4)) + 1;
                string kodeurutan = "0000" + count;
                urut = "SP" + kodeurutan.Substring(kodeurutan.Length - 4, 4);
            }
            else
            {
                urut = "SP0001";
            }
            rd.Close();
            idSupplier.Enabled = false;
            idSupplier.Text = urut;
            conn.Close();
        }

        private void MasterSupplier_Load(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            DataTable dt = new DataTable();
            SqlCommand search = new SqlCommand("SELECT * FROM Supplier", con); //query 
            SqlDataAdapter adapter = new SqlDataAdapter(search);
            adapter.Fill(dt); //masukkan data ke dt (DataTable)
            dataGridView1.DataSource = dt;

            generateID();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand insert = new SqlCommand("INSERT INTO Supplier VALUES(@id, @name, @address, @phone)", con);
            insert.Parameters.AddWithValue("@id", idSupplier.Text);
            insert.Parameters.AddWithValue("@name", namaSupplier.Text); //ambil variabel dri text box
            insert.Parameters.AddWithValue("@address", alamatSupplier.Text);
            insert.Parameters.AddWithValue("@phone", telpSupplier.Text);

            SqlDataAdapter adapter = new SqlDataAdapter(insert); //adapter

            try
            {
                con.Open();
                insert.ExecuteNonQuery();
                MessageBox.Show("Data telah di input");
                dataGridView1.Refresh();
            }
            catch
            {
                MessageBox.Show("Data Gagal diinput");
            }
            finally
            {

                con.Close();
                disp_data();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand update = new SqlCommand("UPDATE Supplier SET SupplierName = @name, SupplierAddress = @address, SupplierPhone = @phone  WHERE SupplierID = @supplierid", con);
            update.Parameters.AddWithValue("@supplierid", idSupplier.Text); //ambil variabel dri text box
            update.Parameters.AddWithValue("@name", namaSupplier.Text);
            update.Parameters.AddWithValue("@address", alamatSupplier.Text);
            update.Parameters.AddWithValue("@phone", telpSupplier.Text);

            SqlDataAdapter adapter = new SqlDataAdapter(update); //adapter

            try
            {
                con.Open();
                update.ExecuteNonQuery();
                MessageBox.Show("Data telah diupdate");
            }
            catch
            {
                MessageBox.Show("Data Gagal diupdate");
            }
            finally
            {

                con.Close();
                disp_data();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand delete = new SqlCommand("DELETE from Supplier where SupplierID = @supplierid", con); //query
            delete.Parameters.AddWithValue("@supplierid", idSupplier.Text);

            try
            {
                con.Open();
                delete.ExecuteNonQuery();
                MessageBox.Show("Data telah di hapus");

            }
            catch
            {
                MessageBox.Show("Data Gagal dihapus");
            }
            finally
            {

                con.Close();
                disp_data();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            idSupplier.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            namaSupplier.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            alamatSupplier.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            telpSupplier.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            idSupplier.Clear();
            namaSupplier.Clear();
            alamatSupplier.Clear();
            telpSupplier.Clear();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            generateID();
        }

        public void disp_data()
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM Supplier";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection conn = new SqlConnection(constring);

            SqlCommand cmd = new SqlCommand("SELECT * FROM Supplier WHERE SupplierID LIKE '%" + textBox1.Text + "%' OR SupplierName LIKE '%" + textBox1.Text + "%'", conn);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void MasterSupplier_FormClosed(object sender, FormClosedEventArgs e)
        {

        }
    }
}
