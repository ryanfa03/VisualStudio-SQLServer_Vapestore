﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectVisualProgramming_Kelompok1
{
    public partial class SalesBarang : Form
    {
        public SalesBarang()
        {
            InitializeComponent();

            dataGridView2.ColumnCount = 5;
            dataGridView2.Columns[0].Name = "ItemID";
            dataGridView2.Columns[1].Name = "ItemCategoryID";
            dataGridView2.Columns[2].Name = "ItemName";
            dataGridView2.Columns[3].Name = "ItemPrice";
            dataGridView2.Columns[4].Name = "OrderQty";

            dataGridView2.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView2.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView2.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView2.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView2.Columns[4].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }
       
        static string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
        SqlConnection con = new SqlConnection(constring);

        void generateID()
        {
            long count;
            string urut;
            SqlDataReader rd;
            con.Open();
            SqlCommand cmd = new SqlCommand("Select OrderID FROM Orders " +
                "WHERE OrderID in(SELECT MAX(OrderID) FROM Orders) ORDER BY OrderID DESC", con);
            rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                count = Convert.ToInt64(rd[0].ToString().Substring(rd["OrderID"].ToString().Length - 4, 4)) + 1;
                string kodeurutan = "0000" + count;
                urut = "SL" + kodeurutan.Substring(kodeurutan.Length - 4, 4);
            }
            else
            {
                urut = "SL0001";
            }
            rd.Close();
            idSales.Enabled = false;
            idSales.Text = urut;
            con.Close();
        }
      
        private void SalesBarang_Load(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            DataTable dt = new DataTable();
            SqlCommand searchorder = new SqlCommand("SELECT b.OrderID, a.EmployeeID, a.PaymentMethodID, a.OrderDate" +
                ", b.ItemID, b.ItemCategoryID, b.ItemName, b.ItemPrice, b.OrderQty FROM Orders a JOIN OrdersDetail b ON a.OrderID = b.OrderID", con);

            SqlDataAdapter adapter = new SqlDataAdapter(searchorder);
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;

            SqlCommand cmd1 = new SqlCommand("SELECT * FROM Employee", con);
            SqlDataAdapter da1 = new SqlDataAdapter();
            da1.SelectCommand = cmd1;
            DataTable table1 = new DataTable();
            da1.Fill(table1);

            idEmployee.DataSource = table1;
            idEmployee.DisplayMember = "EmployeeID";
            idEmployee.ValueMember = "EmployeeID";

            SqlCommand cmd2 = new SqlCommand("SELECT * FROM PaymentMethod", con);
            SqlDataAdapter da2 = new SqlDataAdapter();
            da2.SelectCommand = cmd2;
            DataTable table2 = new DataTable();
            da2.Fill(table2);

            idPayment.DataSource = table2;
            idPayment.DisplayMember = "PaymentMethodID";
            idPayment.ValueMember = "PaymentMethodID";

            SqlCommand cmd3 = new SqlCommand("SELECT * FROM ItemCategory", con);
            SqlDataAdapter da3 = new SqlDataAdapter();
            da3.SelectCommand = cmd3;
            DataTable table3 = new DataTable();
            da3.Fill(table3);

            idKategori.DataSource = table3;
            idKategori.DisplayMember = "ItemCategoryID";
            idKategori.ValueMember = "ItemCategoryID";

            dataGridView1.Columns[7].DefaultCellStyle.Format = "###,###";

            generateID();
        }
        private void button1_Click(object sender, EventArgs e)
        {
           
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand insertorder = new SqlCommand("INSERT INTO Orders (OrderID, EmployeeID,PaymentMethodID, OrderDate) VALUES (@orderid, @employee, " +
                "@payment, @date)", con);
            insertorder.Parameters.AddWithValue("@orderid", idSales.Text);
            insertorder.Parameters.AddWithValue("@employee", idEmployee.Text); //ambil variabel dri text box
            insertorder.Parameters.AddWithValue("@payment", idPayment.Text);
            insertorder.Parameters.AddWithValue("@date", dateTimePicker1.Value.Date);

           
            SqlDataAdapter adapter = new SqlDataAdapter(insertorder); //adapter

            try
            {
                con.Open();
                insertorder.ExecuteNonQuery();
                MessageBox.Show("Data telah di input");
            }
            catch
            {
                MessageBox.Show("Data Gagal diinput");
            }
            finally
            {
                con.Close();
            }

            for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
            {
                SqlCommand insertorderdetail = new SqlCommand("INSERT INTO OrdersDetail VALUES (@orderid, '" + dataGridView2.Rows[i].Cells[0].Value + "'," +
                    "'" + dataGridView2.Rows[i].Cells[1].Value + "','" + dataGridView2.Rows[i].Cells[2].Value + "','" + dataGridView2.Rows[i].Cells[3].Value + 
                    "','" + dataGridView2.Rows[i].Cells[4].Value + "')", con);
                insertorderdetail.Parameters.AddWithValue("@orderid", idSales.Text);
                SqlDataAdapter adapter2 = new SqlDataAdapter(insertorderdetail);//adapter
                con.Open();
                insertorderdetail.ExecuteNonQuery();
                con.Close();

            }
            dataGridView2.Rows.Clear();
            disp_data();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand update1 = new SqlCommand("UPDATE Orders SET EmployeeID = @employee, PaymentMethodID = @paymentid, OrderDate = @date " +
                "WHERE OrderID = @invoiceid", con);
            update1.Parameters.AddWithValue("@invoiceid", idSales.Text);
            update1.Parameters.AddWithValue("@employee", idEmployee.Text); //ambil variabel dri text box
            update1.Parameters.AddWithValue("@paymentid", idPayment.Text);
            update1.Parameters.AddWithValue("@date", dateTimePicker1.Value.Date); 

            SqlCommand update2 = new SqlCommand("UPDATE OrdersDetail SET ItemID = @itemid, ItemCategoryID = @categoryid, ItemName = @name, " +
                "ItemPrice = @price, OrderQty = @qty WHERE OrderID = @invoiceid", con);
            update2.Parameters.AddWithValue("@invoiceid", idSales.Text);
            update2.Parameters.AddWithValue("@itemid", idBarang.Text);
            update2.Parameters.AddWithValue("@categoryid", idKategori.Text);
            update2.Parameters.AddWithValue("@name", namaBarang.Text);
            update2.Parameters.AddWithValue("@price", hargaBarang.Text);
            update2.Parameters.AddWithValue("@qty", jumlahBarang.Text);

            SqlDataAdapter adapter = new SqlDataAdapter(update1);
            SqlDataAdapter adapter2 = new SqlDataAdapter(update2); //adapter

            try
            {
                con.Open();
                update1.ExecuteNonQuery();
                update2.ExecuteNonQuery();
                MessageBox.Show("Data telah diupdate");
            }
            catch
            {
                MessageBox.Show("Data gagal diupdate");
            }
            finally
            {
                con.Close();
                disp_data();
            }
        }
        public void disp_data()
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT b.OrderID, a.EmployeeID, a.PaymentMethodID, a.OrderDate" +
                ", b.ItemID, b.ItemCategoryID, b.ItemName, b.ItemPrice, b.OrderQty FROM Orders a JOIN OrdersDetail b ON a.OrderID = b.OrderID";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();

        }
        private void button4_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand delete1 = new SqlCommand("DELETE from OrdersDetail where OrderID = @invoiceid", con);
            delete1.Parameters.AddWithValue("@invoiceid", idSales.Text);
            SqlCommand delete2 = new SqlCommand("DELETE from Orders where OrderID = @invoiceid", con); //query
            delete2.Parameters.AddWithValue("@invoiceid", idSales.Text);
            

            try
            {
                con.Open();
                delete1.ExecuteNonQuery();
                delete2.ExecuteNonQuery();
                MessageBox.Show("Data telah dihapus");
                disp_data();
            }
            catch
            {
                MessageBox.Show("Data Gagal dihapus");
            }
            finally
            {

                con.Close();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            idSales.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            idEmployee.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            idPayment.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            idBarang.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            idKategori.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            namaBarang.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            hargaBarang.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            jumlahBarang.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SearchEmployeeSales searchEmployee = new SearchEmployeeSales();
            searchEmployee.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            SearchPaymentMethod searchPayment = new SearchPaymentMethod();
            searchPayment.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SearchItemSales searchItem = new SearchItemSales();
            searchItem.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            generateID();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection conn = new SqlConnection(constring);

            SqlCommand cmd = new SqlCommand("SELECT b.OrderID, a.EmployeeID, a.PaymentMethodID, a.OrderDate" +
                ", b.ItemID, b.ItemCategoryID, b.ItemName, b.ItemPrice, b.OrderQty FROM Orders a JOIN OrdersDetail b ON a.OrderID = b.OrderID " +
                "WHERE b.OrderID LIKE '%" + textBox1.Text + "%'", conn);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridView2.CurrentCell.RowIndex;
            dataGridView2.Rows.RemoveAt(rowIndex);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            dataGridView2.Rows.Add(idBarang.Text, idKategori.Text, namaBarang.Text, hargaBarang.Text, jumlahBarang.Text);
        }
        private void SalesBarang_FormClosed(object sender, FormClosedEventArgs e)
        {

        }
    }
}
