﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectVisualProgramming_Kelompok1
{
    public partial class OrderBarang : Form
    {   
        public OrderBarang()
        {
            InitializeComponent();

            dataGridView2.ColumnCount = 4;
            dataGridView2.Columns[0].Name = "ItemID";
            dataGridView2.Columns[1].Name = "ItemCategoryID";
            dataGridView2.Columns[2].Name = "ItemName";
            dataGridView2.Columns[3].Name = "ItemQty";

            dataGridView2.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView2.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView2.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView2.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

        }

        static string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
        SqlConnection con = new SqlConnection(constring);

        void generateID()
        {
            long count;
            string urut;
            SqlDataReader rd;
            con.Open();
            SqlCommand cmd = new SqlCommand("Select PurchaseOrderID FROM PurchaseOrder " +
                "WHERE PurchaseOrderID in(SELECT MAX(PurchaseOrderID) FROM PurchaseOrder) ORDER BY PurchaseOrderID DESC", con);
            rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                count = Convert.ToInt64(rd[0].ToString().Substring(rd["PurchaseOrderID"].ToString().Length - 4, 4)) + 1;
                string kodeurutan = "0000" + count;
                urut = "PO" + kodeurutan.Substring(kodeurutan.Length - 4, 4);
            }
            else
            {
                urut = "PO0001";
            }
            rd.Close();
            idPurchaseOrder.Enabled = false;
            idPurchaseOrder.Text = urut;
            con.Close();
        }

        private void OrderBarang_Load(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            DataTable dt = new DataTable();
            SqlCommand searchorder = new SqlCommand("SELECT b.PurchaseOrderID, a.EmployeeID, a.SupplierID, a.OrderDate, b.ItemID, b.ItemCategoryID, b.ItemName, b.ItemQty" +
                " FROM PurchaseOrder a JOIN PurchaseOrderDetail b ON a.PurchaseOrderID = b.PurchaseOrderID ", con); //query
            SqlDataAdapter adapter = new SqlDataAdapter(searchorder);
            adapter.Fill(dt); //masukkan data ke dt (DataTable)
            dataGridView1.DataSource = dt;

            SqlCommand cmd1 = new SqlCommand("SELECT * FROM Employee", con);
            SqlDataAdapter da1 = new SqlDataAdapter();
            da1.SelectCommand = cmd1;
            DataTable table1 = new DataTable();
            da1.Fill(table1);

            idEmployee.DataSource = table1;
            idEmployee.DisplayMember = "EmployeeID";
            idEmployee.ValueMember = "EmployeeID";

            SqlCommand cmd2 = new SqlCommand("SELECT * FROM Supplier", con);
            SqlDataAdapter da2 = new SqlDataAdapter();
            da2.SelectCommand = cmd2;
            DataTable table2 = new DataTable();
            da2.Fill(table2);

            idSupplier.DataSource = table2;
            idSupplier.DisplayMember = "SupplierID";
            idSupplier.ValueMember = "SupplierID";

            SqlCommand cmd3 = new SqlCommand("SELECT * FROM ItemCategory", con);
            SqlDataAdapter da3 = new SqlDataAdapter();
            da3.SelectCommand = cmd3;
            DataTable table3 = new DataTable();
            da3.Fill(table3);

            idKategori.DataSource = table3;
            idKategori.DisplayMember = "ItemCategoryID";
            idKategori.ValueMember = "ItemCategoryID";

            generateID();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand insertorder = new SqlCommand("INSERT INTO PurchaseOrder VALUES (@poid, @employee, @supplier, @date)", con);
            insertorder.Parameters.AddWithValue("@poid", idPurchaseOrder.Text);
            insertorder.Parameters.AddWithValue("@employee", idEmployee.Text); //ambil variabel dri text box
            insertorder.Parameters.AddWithValue("@supplier", idSupplier.Text);
            insertorder.Parameters.AddWithValue("@date", dateTimePicker1.Value.Date);
            SqlDataAdapter adapter1 = new SqlDataAdapter(insertorder);
            

            try
            {
                con.Open();
                insertorder.ExecuteNonQuery();
                MessageBox.Show("Data telah di input");
            }
            catch
            {
                MessageBox.Show("Data Gagal diinput");
            }
            finally
            {

                con.Close();
            }

            for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
            {
                SqlCommand insertorderdetail = new SqlCommand("INSERT INTO PurchaseOrderDetail VALUES (@poid, '" + dataGridView2.Rows[i].Cells[0].Value + "','" + dataGridView2.Rows[i].Cells[1].Value + "','" + dataGridView2.Rows[i].Cells[2].Value + "','" + dataGridView2.Rows[i].Cells[3].Value + "')", con);
                insertorderdetail.Parameters.AddWithValue("@poid", idPurchaseOrder.Text);
                SqlDataAdapter adapter2 = new SqlDataAdapter(insertorderdetail);//adapter
                con.Open();
                insertorderdetail.ExecuteNonQuery();
                con.Close();

            }
            dataGridView2.Rows.Clear();
            disp_data();
        }
       
        private void button2_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand update = new SqlCommand("UPDATE PurchaseOrder SET EmployeeID = @employee, SupplierID = @supplier, OrderDate = @date WHERE PurchaseOrderID = @poid", con);
            update.Parameters.AddWithValue("@poid", idPurchaseOrder.Text);
            update.Parameters.AddWithValue("@employee", idEmployee.Text); //ambil variabel dri text box
            update.Parameters.AddWithValue("@supplier", idSupplier.Text);
            update.Parameters.AddWithValue("@date", dateTimePicker1.Value.Date);

            SqlCommand update2 = new SqlCommand("UPDATE PurchaseOrderDetail SET ItemID = @itemid, ItemCategoryID = @categoryid, ItemName = @name, ItemQty = @qty WHERE PurchaseOrderID = @poid", con);
            update2.Parameters.AddWithValue("@poid", idPurchaseOrder.Text);
            update2.Parameters.AddWithValue("@itemid", idBarang.Text);
            update2.Parameters.AddWithValue("@categoryid", idKategori.Text);
            update2.Parameters.AddWithValue("@name", namaBarang.Text);
            update2.Parameters.AddWithValue("@qty", jumlahBarang.Text);

            SqlDataAdapter adapter = new SqlDataAdapter(update);
            SqlDataAdapter adapter2 = new SqlDataAdapter(update2);
            try
            {
                con.Open();

                update.ExecuteNonQuery();
                update2.ExecuteNonQuery();

                MessageBox.Show("Data telah diupdate");
                disp_data();
            }
            catch
            {
                MessageBox.Show("Data Gagal diupdate");
            }
            finally
            {

                con.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand delete = new SqlCommand("DELETE from PurchaseOrderDetail where PurchaseOrderID = @poid", con); //query
            delete.Parameters.AddWithValue("@poid", idPurchaseOrder.Text);
            SqlCommand delete2 = new SqlCommand("DELETE from PurchaseOrder where PurchaseOrderID = @poid", con);
            delete2.Parameters.AddWithValue("@poid", idPurchaseOrder.Text);

            try
            {
                con.Open();
                delete.ExecuteNonQuery();
                delete2.ExecuteNonQuery();
                MessageBox.Show("Data telah dihapus");
                disp_data();
            }
            catch
            {
                MessageBox.Show("Data Gagal dihapus");
            }
            finally
            {

                con.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            idPurchaseOrder.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            idEmployee.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            idSupplier.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            idBarang.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            idKategori.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            namaBarang.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            jumlahBarang.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
        }
        private void button5_Click(object sender, EventArgs e)
        {
            SearchEmployeePurchaseOrder searchEmployee = new SearchEmployeePurchaseOrder();
            searchEmployee.Show();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            SearchSupplier searchSupplier = new SearchSupplier();
            searchSupplier.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            SearchItemPurchaseOrder searchItem = new SearchItemPurchaseOrder();
            searchItem.Show();
        }
        public void disp_data()
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT b.PurchaseOrderID, a.EmployeeID, a.SupplierID, a.OrderDate, b.ItemID, b.ItemCategoryID, b.ItemName, b.ItemQty" +
                " FROM PurchaseOrder a JOIN PurchaseOrderDetail b ON a.PurchaseOrderID = b.PurchaseOrderID";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection conn = new SqlConnection(constring);

            SqlCommand cmd = new SqlCommand("SELECT b.PurchaseOrderID, a.EmployeeID, a.SupplierID, a.OrderDate, b.ItemID, b.ItemCategoryID, b.ItemName, b.ItemQty" +
                " FROM PurchaseOrder a JOIN PurchaseOrderDetail b ON a.PurchaseOrderID = b.PurchaseOrderID WHERE b.PurchaseOrderID LIKE '%" + searchpoid.Text + "%'", conn);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            dataGridView2.Rows.Add(idBarang.Text, idKategori.Text, namaBarang.Text, jumlahBarang.Text);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            int rowIndex = dataGridView2.CurrentCell.RowIndex;
            dataGridView2.Rows.RemoveAt(rowIndex);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            generateID();
        }


        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void OrderBarang_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

    }
}
