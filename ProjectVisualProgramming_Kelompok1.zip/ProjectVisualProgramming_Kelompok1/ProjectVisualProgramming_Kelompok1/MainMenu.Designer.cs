﻿
namespace ProjectVisualProgramming_Kelompok1
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.masterBarangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.masterBarangToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.masterSupplierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.masterEmployeeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.masterCategorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.masterPaymentMethodToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transactionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.orderBarangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salesBarangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportOrderBarangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportPenjualanToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportDataBarangToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportOrderTotxtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportOrderTotxtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportSalesTotxtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Azure;
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.masterBarangToolStripMenuItem,
            this.transactionToolStripMenuItem,
            this.reportToolStripMenuItem,
            this.fileToolStripMenuItem,
            this.logOutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1207, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // masterBarangToolStripMenuItem
            // 
            this.masterBarangToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.masterBarangToolStripMenuItem1,
            this.masterSupplierToolStripMenuItem,
            this.masterEmployeeToolStripMenuItem,
            this.masterCategorToolStripMenuItem,
            this.masterPaymentMethodToolStripMenuItem});
            this.masterBarangToolStripMenuItem.Name = "masterBarangToolStripMenuItem";
            this.masterBarangToolStripMenuItem.Size = new System.Drawing.Size(82, 29);
            this.masterBarangToolStripMenuItem.Text = "Master";
            this.masterBarangToolStripMenuItem.Click += new System.EventHandler(this.masterBarangToolStripMenuItem_Click);
            // 
            // masterBarangToolStripMenuItem1
            // 
            this.masterBarangToolStripMenuItem1.Name = "masterBarangToolStripMenuItem1";
            this.masterBarangToolStripMenuItem1.Size = new System.Drawing.Size(304, 34);
            this.masterBarangToolStripMenuItem1.Text = "Master Barang";
            this.masterBarangToolStripMenuItem1.Click += new System.EventHandler(this.masterBarangToolStripMenuItem1_Click);
            // 
            // masterSupplierToolStripMenuItem
            // 
            this.masterSupplierToolStripMenuItem.Name = "masterSupplierToolStripMenuItem";
            this.masterSupplierToolStripMenuItem.Size = new System.Drawing.Size(304, 34);
            this.masterSupplierToolStripMenuItem.Text = "Master Supplier";
            this.masterSupplierToolStripMenuItem.Click += new System.EventHandler(this.masterSupplierToolStripMenuItem_Click);
            // 
            // masterEmployeeToolStripMenuItem
            // 
            this.masterEmployeeToolStripMenuItem.Name = "masterEmployeeToolStripMenuItem";
            this.masterEmployeeToolStripMenuItem.Size = new System.Drawing.Size(304, 34);
            this.masterEmployeeToolStripMenuItem.Text = "Master Employee";
            this.masterEmployeeToolStripMenuItem.Click += new System.EventHandler(this.masterEmployeeToolStripMenuItem_Click);
            // 
            // masterCategorToolStripMenuItem
            // 
            this.masterCategorToolStripMenuItem.Name = "masterCategorToolStripMenuItem";
            this.masterCategorToolStripMenuItem.Size = new System.Drawing.Size(304, 34);
            this.masterCategorToolStripMenuItem.Text = "Master Category";
            this.masterCategorToolStripMenuItem.Click += new System.EventHandler(this.masterCategorToolStripMenuItem_Click);
            // 
            // masterPaymentMethodToolStripMenuItem
            // 
            this.masterPaymentMethodToolStripMenuItem.Name = "masterPaymentMethodToolStripMenuItem";
            this.masterPaymentMethodToolStripMenuItem.Size = new System.Drawing.Size(304, 34);
            this.masterPaymentMethodToolStripMenuItem.Text = "Master PaymentMethod";
            this.masterPaymentMethodToolStripMenuItem.Click += new System.EventHandler(this.masterPaymentMethodToolStripMenuItem_Click);
            // 
            // transactionToolStripMenuItem
            // 
            this.transactionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.orderBarangToolStripMenuItem,
            this.salesBarangToolStripMenuItem});
            this.transactionToolStripMenuItem.Name = "transactionToolStripMenuItem";
            this.transactionToolStripMenuItem.Size = new System.Drawing.Size(116, 29);
            this.transactionToolStripMenuItem.Text = "Transaction";
            // 
            // orderBarangToolStripMenuItem
            // 
            this.orderBarangToolStripMenuItem.Name = "orderBarangToolStripMenuItem";
            this.orderBarangToolStripMenuItem.Size = new System.Drawing.Size(220, 34);
            this.orderBarangToolStripMenuItem.Text = "Order Barang";
            this.orderBarangToolStripMenuItem.Click += new System.EventHandler(this.orderBarangToolStripMenuItem_Click);
            // 
            // salesBarangToolStripMenuItem
            // 
            this.salesBarangToolStripMenuItem.Name = "salesBarangToolStripMenuItem";
            this.salesBarangToolStripMenuItem.Size = new System.Drawing.Size(220, 34);
            this.salesBarangToolStripMenuItem.Text = "Sales Barang";
            this.salesBarangToolStripMenuItem.Click += new System.EventHandler(this.salesBarangToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reportOrderBarangToolStripMenuItem,
            this.reportPenjualanToolStripMenuItem,
            this.reportDataBarangToolStripMenuItem});
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(81, 29);
            this.reportToolStripMenuItem.Text = "Report";
            // 
            // reportOrderBarangToolStripMenuItem
            // 
            this.reportOrderBarangToolStripMenuItem.Name = "reportOrderBarangToolStripMenuItem";
            this.reportOrderBarangToolStripMenuItem.Size = new System.Drawing.Size(278, 34);
            this.reportOrderBarangToolStripMenuItem.Text = "Report Order Barang";
            this.reportOrderBarangToolStripMenuItem.Click += new System.EventHandler(this.reportOrderBarangToolStripMenuItem_Click);
            // 
            // reportPenjualanToolStripMenuItem
            // 
            this.reportPenjualanToolStripMenuItem.Name = "reportPenjualanToolStripMenuItem";
            this.reportPenjualanToolStripMenuItem.Size = new System.Drawing.Size(278, 34);
            this.reportPenjualanToolStripMenuItem.Text = "Report Sales";
            this.reportPenjualanToolStripMenuItem.Click += new System.EventHandler(this.reportPenjualanToolStripMenuItem_Click);
            // 
            // reportDataBarangToolStripMenuItem
            // 
            this.reportDataBarangToolStripMenuItem.Name = "reportDataBarangToolStripMenuItem";
            this.reportDataBarangToolStripMenuItem.Size = new System.Drawing.Size(278, 34);
            this.reportDataBarangToolStripMenuItem.Text = "Report Data Barang";
            this.reportDataBarangToolStripMenuItem.Click += new System.EventHandler(this.reportDataBarangToolStripMenuItem_Click);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportOrderTotxtToolStripMenuItem,
            this.reportOrderTotxtToolStripMenuItem,
            this.reportSalesTotxtToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(54, 29);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // exportOrderTotxtToolStripMenuItem
            // 
            this.exportOrderTotxtToolStripMenuItem.Name = "exportOrderTotxtToolStripMenuItem";
            this.exportOrderTotxtToolStripMenuItem.Size = new System.Drawing.Size(269, 34);
            this.exportOrderTotxtToolStripMenuItem.Text = "Data Barang to .txt";
            this.exportOrderTotxtToolStripMenuItem.Click += new System.EventHandler(this.exportOrderTotxtToolStripMenuItem_Click);
            // 
            // reportOrderTotxtToolStripMenuItem
            // 
            this.reportOrderTotxtToolStripMenuItem.Name = "reportOrderTotxtToolStripMenuItem";
            this.reportOrderTotxtToolStripMenuItem.Size = new System.Drawing.Size(269, 34);
            this.reportOrderTotxtToolStripMenuItem.Text = "Report Order to .txt";
            this.reportOrderTotxtToolStripMenuItem.Click += new System.EventHandler(this.reportOrderTotxtToolStripMenuItem_Click);
            // 
            // reportSalesTotxtToolStripMenuItem
            // 
            this.reportSalesTotxtToolStripMenuItem.Name = "reportSalesTotxtToolStripMenuItem";
            this.reportSalesTotxtToolStripMenuItem.Size = new System.Drawing.Size(269, 34);
            this.reportSalesTotxtToolStripMenuItem.Text = "Report Sales to .txt";
            this.reportSalesTotxtToolStripMenuItem.Click += new System.EventHandler(this.reportSalesTotxtToolStripMenuItem_Click);
            // 
            // logOutToolStripMenuItem
            // 
            this.logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            this.logOutToolStripMenuItem.Size = new System.Drawing.Size(93, 29);
            this.logOutToolStripMenuItem.Text = "Log Out";
            this.logOutToolStripMenuItem.Click += new System.EventHandler(this.logOutToolStripMenuItem_Click);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(1207, 386);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "MainMenu";
            this.Text = "MainMenu";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainMenu_FormClosed);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem masterBarangToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transactionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem orderBarangToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salesBarangToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportOrderBarangToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportPenjualanToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportOrderTotxtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportOrderTotxtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportSalesTotxtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem masterBarangToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem masterSupplierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem masterEmployeeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem masterCategorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportDataBarangToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem masterPaymentMethodToolStripMenuItem;
    }
}