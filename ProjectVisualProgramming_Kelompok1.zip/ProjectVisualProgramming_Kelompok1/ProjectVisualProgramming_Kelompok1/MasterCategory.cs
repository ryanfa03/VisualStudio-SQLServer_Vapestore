﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectVisualProgramming_Kelompok1
{
    public partial class MasterCategory : Form
    {

        public MasterCategory()
        {
            InitializeComponent();
        }

        static string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
        SqlConnection conn = new SqlConnection(constring);

        void generateID()
        {
            long count;
            string urut;
            SqlDataReader rd;
            conn.Open();
            SqlCommand cmd = new SqlCommand("Select ItemCategoryID FROM ItemCategory " +
                "WHERE ItemCategoryID in(SELECT MAX(ItemCategoryID) FROM ItemCategory) ORDER BY ItemCategoryID DESC", conn);
            rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                count = Convert.ToInt64(rd[0].ToString().Substring(rd["ItemCategoryID"].ToString().Length - 4, 4)) + 1;
                string kodeurutan = "0000" + count;
                urut = "CT" + kodeurutan.Substring(kodeurutan.Length - 4, 4);
            }
            else
            {
                urut = "CT0001";
            }
            rd.Close();
            idKategori.Enabled = false;
            idKategori.Text = urut;
            conn.Close();
        }

        private void MasterCategory_Load(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            DataTable dt = new DataTable();
            SqlCommand search = new SqlCommand("SELECT * FROM ItemCategory", con); //query 
            SqlDataAdapter adapter = new SqlDataAdapter(search);
            adapter.Fill(dt); //masukkan data ke dt (DataTable)
            dataGridView1.DataSource = dt;

            generateID();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand insert = new SqlCommand("INSERT INTO ItemCategory VALUES(@id, @categoryname)", con);
            insert.Parameters.AddWithValue("@id", idKategori.Text);
            insert.Parameters.AddWithValue("@categoryname", namaKategori.Text); //ambil variabel dri text box

            SqlDataAdapter adapter = new SqlDataAdapter(insert); //adapter

            try
            {
                con.Open();
                insert.ExecuteNonQuery();
                MessageBox.Show("Data telah di input");
                dataGridView1.Refresh();
            }
            catch
            {
                MessageBox.Show("Data Gagal diinput");
            }
            finally
            {

                con.Close();
                disp_data();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand update = new SqlCommand("UPDATE ItemCategory SET ItemCategoryName = @nama WHERE ItemCategoryID = @id", con);
            update.Parameters.AddWithValue("@id", idKategori.Text); //ambil variabel dri text box
            update.Parameters.AddWithValue("@nama", namaKategori.Text);

            SqlDataAdapter adapter = new SqlDataAdapter(update); //adapter

            try
            {
                con.Open();
                update.ExecuteNonQuery();
                MessageBox.Show("Data telah diupdate");
                dataGridView1.Refresh();
            }
            catch
            {
                MessageBox.Show("Data Gagal diupdate");
            }
            finally
            {
                con.Close();
                disp_data();
            }

        }
        private void button3_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand delete = new SqlCommand("DELETE from ItemCategory where ItemCategoryID = @id", con); //query
            delete.Parameters.AddWithValue("@id", idKategori.Text);

            try
            {
                con.Open();
                delete.ExecuteNonQuery();
                MessageBox.Show("Data telah di hapus");
            }
            catch
            {
                MessageBox.Show("Data Gagal dihapus");
            }
            finally
            {

                con.Close();
                disp_data();
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            idKategori.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            namaKategori.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();

        }
        private void button5_Click(object sender, EventArgs e)
        {
            idKategori.Clear();
            namaKategori.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            generateID();
        }
        public void disp_data()
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM ItemCategory";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection conn = new SqlConnection(constring);

            SqlCommand cmd = new SqlCommand("SELECT * FROM ItemCategory WHERE ItemCategoryID LIKE '%" + textBox1.Text + "%' OR ItemCategoryName LIKE '%" + textBox1.Text + "%'", conn);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void MasterCategory_FormClosed(object sender, FormClosedEventArgs e)
        {

        }
    }
}
