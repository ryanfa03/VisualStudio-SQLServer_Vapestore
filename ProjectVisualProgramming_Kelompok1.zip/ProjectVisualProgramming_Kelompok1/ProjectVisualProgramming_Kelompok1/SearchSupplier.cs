﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectVisualProgramming_Kelompok1
{
    public partial class SearchSupplier : Form
    {
        public SearchSupplier()
        {
            InitializeComponent();
        }

        private void SearchSupplier_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projectDataSet8.Supplier' table. You can move, or remove it, as needed.
            this.supplierTableAdapter1.Fill(this.projectDataSet8.Supplier);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection conn = new SqlConnection(constring);

            SqlCommand cmd = new SqlCommand("SELECT * FROM Supplier WHERE SupplierID LIKE '%" + textBox1.Text + "%' OR SupplierName LIKE '%" + textBox1.Text + "%'", conn);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OrderBarang orderBarang = (OrderBarang)Application.OpenForms["OrderBarang"];
            orderBarang.idSupplier.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
        }
    }
}
