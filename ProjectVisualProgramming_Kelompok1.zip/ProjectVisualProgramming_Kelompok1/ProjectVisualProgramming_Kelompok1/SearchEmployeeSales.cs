﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectVisualProgramming_Kelompok1
{
    public partial class SearchEmployeeSales : Form
    {
        public SearchEmployeeSales()
        {
            InitializeComponent();
        }

        private void SearchEmployeeSales_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projectDataSet11.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter1.Fill(this.projectDataSet11.Employee);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection conn = new SqlConnection(constring);

            SqlCommand cmd = new SqlCommand("SELECT * FROM Employee WHERE EmployeeID LIKE '%" + textBox1.Text + "%' OR EmployeeName LIKE '%" + textBox1.Text + "%'", conn);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SalesBarang salesBarang = (SalesBarang)Application.OpenForms["SalesBarang"];
            salesBarang.idEmployee.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
        }
    }
}
