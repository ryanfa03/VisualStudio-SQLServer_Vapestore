﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ProjectVisualProgramming_Kelompok1
{
    public partial class MasterBarang : Form
    {
        public MasterBarang()
        {
            InitializeComponent();
        }

        static string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
        SqlConnection conn = new SqlConnection(constring);

        void generateID()
        {
            long count;
            string urut;
            SqlDataReader rd;
            conn.Open();
            SqlCommand cmd = new SqlCommand("Select ItemID FROM Item " +
                "WHERE ItemID in(SELECT MAX(ItemID) FROM Item) ORDER BY ItemID DESC", conn);
            rd = cmd.ExecuteReader();
            rd.Read();
            if (rd.HasRows)
            {
                count = Convert.ToInt64(rd[0].ToString().Substring(rd["ItemID"].ToString().Length - 4, 4)) + 1;
                string kodeurutan = "0000" + count;
                urut = "IT" + kodeurutan.Substring(kodeurutan.Length - 4, 4);
            }
            else
            {
                urut = "IT0001";
            }
            rd.Close();
            idBarang.Enabled = false;
            idBarang.Text = urut;
            conn.Close();
        }
        private void idgenerate_Click(object sender, EventArgs e)
        {
            generateID();
        }
        private void MasterBarang_Load(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            DataTable dt = new DataTable();
            SqlCommand search = new SqlCommand("SELECT * FROM Item", con); //query 
            SqlDataAdapter adapter = new SqlDataAdapter(search);
            adapter.Fill(dt); //masukkan data ke dt (DataTable)
            dataGridView1.DataSource = dt;

            SqlCommand cmd = new SqlCommand("SELECT * FROM ItemCategory", con);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable table1 = new DataTable();
            da.Fill(table1);

            idKategori.DataSource = table1;
            idKategori.DisplayMember = "ItemCategoryID";
            idKategori.ValueMember = "ItemCategoryID";

            dataGridView1.Columns[5].DefaultCellStyle.Format = "###,###";

            generateID();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand insert = new SqlCommand("INSERT INTO Item VALUES(@iditem, @idcategory,@nama,@desc,@qty,@price)", con);
            insert.Parameters.AddWithValue("@iditem", idBarang.Text);
            insert.Parameters.AddWithValue("@idcategory", idKategori.Text);
            insert.Parameters.AddWithValue("@nama", namaBarang.Text);
            insert.Parameters.AddWithValue("@desc", descBarang.Text);
            insert.Parameters.AddWithValue("@qty", qtyBarang.Text);
            insert.Parameters.AddWithValue("@price", priceBarang.Text);

            SqlDataAdapter adapter = new SqlDataAdapter(insert); //adapter

            try
            {
                con.Open();
                insert.ExecuteNonQuery();
                MessageBox.Show("Data telah di input");
                dataGridView1.Refresh();
            }
            catch
            {
                MessageBox.Show("Data Gagal diinput");
            }
            finally
            {
                
                con.Close();
                disp_data();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand update = new SqlCommand("UPDATE Item SET ItemCategoryID = @idcat, ItemName = @nama, Description = @desc, ItemQty = @qty, ItemPrice = @price WHERE ItemID = @id", con);
            update.Parameters.AddWithValue("@id", idBarang.Text); //ambil variabel dri text box
            update.Parameters.AddWithValue("@idcat", idKategori.Text);
            update.Parameters.AddWithValue("@nama", namaBarang.Text);
            update.Parameters.AddWithValue("@desc", descBarang.Text);
            update.Parameters.AddWithValue("@qty", qtyBarang.Text);
            update.Parameters.AddWithValue("@price", priceBarang.Text);

            SqlDataAdapter adapter = new SqlDataAdapter(update); //adapter

            try
            {
                con.Open();
                update.ExecuteNonQuery();
                MessageBox.Show("Data telah diupdate");
                dataGridView1.Refresh();
            }
            catch
            {
                MessageBox.Show("Data Gagal diupdate");
            }
            finally
            {

                con.Close();
                disp_data();
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            SqlCommand delete = new SqlCommand("DELETE from Item where ItemID = @id", con); //query
            delete.Parameters.AddWithValue("@id", idBarang.Text);

            try
            {
                con.Open();
                delete.ExecuteNonQuery();
                MessageBox.Show("Data telah di hapus");

            }
            catch
            {
                MessageBox.Show("Data Gagal dihapus");
            }
            finally
            {

                con.Close();
                disp_data();
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            idBarang.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            idKategori.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            namaBarang.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            descBarang.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            qtyBarang.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            priceBarang.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            idBarang.Clear();
            namaBarang.Clear();
            descBarang.Clear();
            qtyBarang.Clear();
            priceBarang.Clear();
        }

        public void disp_data()
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection con = new SqlConnection(constring);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "SELECT * FROM Item";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;

            con.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string constring = "Data Source=LAPTOP-NRQNV2VF\\SQLEXPRESS;Initial Catalog=project;Integrated Security=True";
            SqlConnection conn = new SqlConnection(constring);

            SqlCommand cmd = new SqlCommand("SELECT * FROM Item WHERE ItemID LIKE '%" + textBox1.Text + "%' OR ItemName LIKE '%" + textBox1.Text + "%'", conn);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            dataGridView1.DataSource = dt;
        }
        private void button6_Click(object sender, EventArgs e)
        {
            SearchItemCategory searchCategory = new SearchItemCategory();
            searchCategory.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void MasterBarang_FormClosed(object sender, FormClosedEventArgs e)
        {

        }
    }
}
