﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectVisualProgramming_Kelompok1
{
    public partial class SalesReport : Form
    {
        public SalesReport()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReportSalesBarang vcr = new ReportSalesBarang();
            crystalReportViewer1.SelectionFormula = "{Orders.OrderDate} = '" + dateTimePicker1.Value.ToString("yyyy-MM-dd") + "'";
            crystalReportViewer1.ReportSource = vcr;
        }
    }
}
