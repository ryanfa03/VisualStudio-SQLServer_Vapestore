﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectVisualProgramming_Kelompok1
{
    public partial class MainMenu : Form
    {   
        public MainMenu()
        {
            InitializeComponent();
        }
        private void orderBarangToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OrderBarang orderBarang = new OrderBarang();
            orderBarang.ShowDialog();
        }
        private void salesBarangToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SalesBarang salesBarang = new SalesBarang();
            salesBarang.ShowDialog();
        }
        private void MainMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Login login = new Login();
            login.Show();        
        }
        private void reportOrderBarangToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OrderReport orderReport = new OrderReport();
            orderReport.ShowDialog();
        }
        private void reportPenjualanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SalesReport salesReport = new SalesReport();
            salesReport.ShowDialog();
        }
        private void exportOrderTotxtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ItemsToFile txt = new ItemsToFile();
            txt.ShowDialog();
        }
        private void reportOrderTotxtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OrdersToFile txt = new OrdersToFile();
            txt.ShowDialog();
        }
        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }
        private void reportSalesTotxtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SalesToFile txt = new SalesToFile();
            txt.ShowDialog();
        }
        private void masterBarangToolStripMenuItem1_Click(object sender, EventArgs e)
        {

            MasterBarang masterBarang = new MasterBarang();
            masterBarang.ShowDialog();
        }
        private void masterCategorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasterCategory masterCategory = new MasterCategory();
            masterCategory.ShowDialog();
        }
        private void masterSupplierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasterSupplier masterSupplier = new MasterSupplier();
            masterSupplier.ShowDialog();
        }
        private void masterPaymentMethodToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasterPaymentMethod masterPayment = new MasterPaymentMethod();
            masterPayment.ShowDialog();
        }
        private void masterEmployeeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasterEmployee masterEmployee = new MasterEmployee();
            masterEmployee.ShowDialog();
        }
        private void reportDataBarangToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BarangReport barang = new BarangReport();
            barang.ShowDialog();
        }

        private void masterBarangToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
